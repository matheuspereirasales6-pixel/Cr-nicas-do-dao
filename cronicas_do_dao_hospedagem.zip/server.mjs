import "dotenv/config";
import express from "express";
import path from "node:path";
import { fileURLToPath } from "node:url";
import OpenAI from "openai";

const __filename=fileURLToPath(import.meta.url);
const __dirname=path.dirname(__filename);

const app=express();
app.use(express.json({limit:"300kb"}));
app.use(express.static(__dirname));

const client=new OpenAI({apiKey:process.env.OPENAI_API_KEY});
const PORT=process.env.PORT||3000;
const MODEL=process.env.OPENAI_MODEL||"gpt-5.6-luna";

const WORLD_RULES=`
Você é o Mestre do Dao de um RPG narrativo de cultivo/xianxia.
O jogador controla UM protagonista. Você é narrador, mundo, NPCs, facções e consequências.
Escreva em português brasileiro.

OBJETIVO:
Criar uma novel interativa de vida inteira, começando no nascimento e podendo chegar a eras muito posteriores.
A história precisa AVANÇAR. Não repita cenas, encontros, capítulos ou situações já concluídas.
O mundo continua existindo e tomando decisões mesmo quando o protagonista não interfere.

REGRAS DE CONTINUIDADE:
1. Nunca contradiga o estado recebido.
2. Nunca ressuscite ou repita um evento registrado em completed.
3. Se uma consequência já aconteceu, trate-a como parte permanente da história.
4. Faça o tempo avançar. Uma ação pode consumir dias, meses ou anos conforme o contexto.
5. NPCs devem lembrar decisões anteriores e relações devem mudar.
6. Use eventos inéditos, mas coerentes com a região, idade, cultivo, reputação e flags.
7. Não transforme cada turno em combate. Infância, estudo, viagens, família, política de seitas, exploração, cultivo, mistérios e cotidiano também importam.
8. Não dê ao protagonista conhecimento que ele não teria. Segredos devem permanecer secretos até serem descobertos.
9. Não force uma única história. As escolhas do jogador mudam os arcos futuros.
10. A morte pode existir como consequência ficcional em alto nível, mas nunca descreva suicídio ou automutilação.
11. Romance, quando surgir, deve permanecer apropriado e não explícito; não faça roleplay romântico em primeira pessoa.
12. Não ofereça instruções reais perigosas; técnicas de cultivo são puramente fantásticas.
13. O texto da cena deve parecer um capítulo de novel, mas sem copiar personagens ou trechos de obras existentes.
14. As opções devem ser consequências reais, não três maneiras de fazer exatamente a mesma coisa.
15. Não encerre a história só porque um arco terminou. Crie o próximo arco a partir das consequências.

MOTOR:
Você recebe o estado atual e uma ação do jogador.
Você deve produzir:
- uma cena narrativa nova;
- 2 a 4 escolhas relevantes;
- um patch estruturado do estado;
- um registro curto para o diário.

Não altere campos fora do patch.
Para números, prefira pequenas mudanças coerentes. Grandes avanços de cultivo devem ser raros.
Se o jogador tentar algo impossível, transforme isso em consequência narrativa em vez de simplesmente permitir.
`;

const schema={
 type:"object",
 additionalProperties:false,
 properties:{
  story:{type:"string"},
  scene_type:{type:"string"},
  chapter_title:{type:"string"},
  location:{type:"string"},
  choices:{
   type:"array",minItems:2,maxItems:4,
   items:{type:"object",additionalProperties:false,properties:{
    label:{type:"string"},hint:{type:"string"}
   },required:["label","hint"]}
  },
  log:{type:"string"},
  patch:{
   type:"object",additionalProperties:false,
   properties:{
    age_delta:{type:"integer",minimum:0,maximum:20},
    days_delta:{type:"integer",minimum:0,maximum:3650},
    cultivation_delta:{type:"integer",minimum:-50,maximum:500},
    body_delta:{type:"integer",minimum:-5,maximum:30},
    qi_delta:{type:"integer",minimum:-5,maximum:30},
    soul_delta:{type:"integer",minimum:-5,maximum:30},
    comprehension_delta:{type:"integer",minimum:-5,maximum:30},
    will_delta:{type:"integer",minimum:-5,maximum:30},
    luck_delta:{type:"integer",minimum:-5,maximum:20},
    reputation_delta:{type:"integer",minimum:-20,maximum:30},
    spirit_stones_delta:{type:"integer",minimum:-1000,maximum:1000},
    location:{type:"string"},
    sect:{type:"string"},
    add_inventory:{type:"array",items:{type:"string"},maxItems:4},
    remove_inventory:{type:"array",items:{type:"string"},maxItems:4},
    add_discoveries:{type:"array",items:{type:"string"},maxItems:3},
    completed_add:{type:"array",items:{type:"string"},maxItems:4},
    flags_set:{type:"array",items:{type:"string"},maxItems:6},
    relation_changes:{
      type:"array",maxItems:4,
      items:{type:"object",additionalProperties:false,properties:{
       name:{type:"string"},delta:{type:"integer",minimum:-20,maximum:20}
      },required:["name","delta"]}
    }
   },
   required:["age_delta","days_delta","cultivation_delta","body_delta","qi_delta","soul_delta","comprehension_delta","will_delta","luck_delta","reputation_delta","spirit_stones_delta","location","sect","add_inventory","remove_inventory","add_discoveries","completed_add","flags_set","relation_changes"]
  }
 },
 required:["story","scene_type","chapter_title","location","choices","log","patch"]
};

function cleanString(x,max=300){return typeof x==="string"?x.slice(0,max):""}
function applyPatch(s,p){
 const n=(key,delta,min=-999999,max=999999)=>{s[key]=Math.max(min,Math.min(max,(Number(s[key])||0)+(Number(delta)||0)))};
 const days=Math.max(0,Math.min(3650,p.days_delta||0));
 s.day=(s.day||1)+days;
 while(s.day>30){s.day-=30;s.month=(s.month||1)+1}
 while(s.month>12){s.month-=12;s.year=(s.year||1)+1}
 if(p.age_delta>0)s.age+=Math.min(20,p.age_delta);

 n("cultivation",p.cultivation_delta,0,100000);
 n("body",p.body_delta,0,100000);n("qi",p.qi_delta,0,100000);n("soul",p.soul_delta,0,100000);
 n("comprehension",p.comprehension_delta,0,100000);n("will",p.will_delta,0,100000);
 n("luck",p.luck_delta,0,100000);n("reputation",p.reputation_delta,-100000,100000);
 n("spiritStones",p.spirit_stones_delta,0,1000000);

 if(p.location)s.location=cleanString(p.location,100);
 if(p.sect)s.sect=cleanString(p.sect,100);
 s.inventory=Array.isArray(s.inventory)?s.inventory:[];
 s.discoveries=Array.isArray(s.discoveries)?s.discoveries:[];
 s.completed=Array.isArray(s.completed)?s.completed:[];
 s.inventory.push(...(p.add_inventory||[]).map(x=>cleanString(x,100)));
 for(const item of (p.remove_inventory||[])){
   const i=s.inventory.indexOf(item);if(i>=0)s.inventory.splice(i,1);
 }
 for(const d of (p.add_discoveries||[])){if(!s.discoveries.includes(d))s.discoveries.push(cleanString(d,180))}
 for(const id of (p.completed_add||[])){if(!s.completed.includes(id))s.completed.push(cleanString(id,80))}
 s.flags=s.flags||{};
 for(const f of (p.flags_set||[]))s.flags[cleanString(f,80)]=true;
 s.relations=s.relations||{};
 for(const r of (p.relation_changes||[])){
   const name=cleanString(r.name,80);
   s.relations[name]=Math.max(0,Math.min(100,(s.relations[name]||50)+(r.delta||0)));
 }
 s.realm=0;
 const needs=[0,40,120,260,520,1000,1800,3000,5000];
 for(let i=needs.length-1;i>=0;i--){if(s.cultivation>=needs[i]){s.realm=i;break}}
 s.chapter=(s.chapter||1)+(p.days_delta>=180?1:0);
 s.chapterTitle=cleanString(p.chapter_title||s.chapterTitle,120);
 s.lastAction="";
 return s;
}

app.post("/api/turn",async(req,res)=>{
 try{
  const {state,action}=req.body||{};
  if(!state||typeof action!=="string"||!action.trim())return res.status(400).json({error:"Estado ou ação ausente."});

  const safeState=JSON.parse(JSON.stringify(state));
  const history=(safeState.storyHistory||[]).slice(-12);
  const input=`
ESTADO ATUAL:
${JSON.stringify(safeState)}

HISTÓRICO RECENTE:
${JSON.stringify(history)}

AÇÃO DO JOGADOR:
${action.trim()}

Gere a próxima cena. Faça o mundo avançar de forma causal.
`;

  const response=await client.responses.create({
   model:MODEL,
   instructions:WORLD_RULES,
   input,
   text:{format:{
    type:"json_schema",
    name:"dao_turn",
    strict:true,
    schema
   }}
  });

  const raw=response.output_text;
  if(!raw)throw new Error("A IA não retornou uma cena.");
  const result=JSON.parse(raw);
  const next=applyPatch(safeState,result.patch);
  next.chapterTitle=result.chapter_title;
  next.lastAction=action.trim();
  next.turn=(next.turn||0)+1;
  next.storyHistory=(next.storyHistory||[]).slice(-29);
  res.json({
   story:result.story,
   scene_type:result.scene_type,
   choices:result.choices,
   log:result.log,
   state:next
  });
 }catch(err){
  console.error(err);
  res.status(500).json({error:"Falha ao gerar a cena. Verifique a chave da API, o modelo e o terminal do servidor."});
 }
});

app.get("/api/health",(req,res)=>res.json({ok:true,model:MODEL}));

app.listen(PORT,()=>console.log(`Crônicas do Dao rodando em http://localhost:${PORT}`));
