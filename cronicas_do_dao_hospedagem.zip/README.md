# Crônicas do Dao — hospedagem

Este pacote está preparado para ser publicado como um Web Service Node.js.

## O que existe

- `index.html` — interface do jogo
- `style.css` — interface visual
- `game.js` — cliente
- `server.mjs` — backend + narrador de IA
- `package.json` — dependências/comandos
- `render.yaml` — configuração de deploy
- `.node-version` — versão do Node
- `.env.example` — variáveis locais
- `.gitignore` — impede enviar `.env`

## Deploy no Render

O `render.yaml` já define:

- runtime Node
- comando de build: `npm install`
- comando de início: `npm start`
- health check: `/api/health`
- `OPENAI_API_KEY` como segredo
- `OPENAI_MODEL` como variável configurável

O Render permite criar um Web Service a partir de um repositório Git e configurar as variáveis de ambiente no painel. A documentação oficial explica o fluxo de criação e os comandos de build/start. 

Depois que o deploy terminar, o Render fornece uma URL pública `onrender.com`. O jogo será aberto nessa URL e o navegador falará com o backend no mesmo domínio.

## Segurança

NUNCA coloque a chave da API em:

- `index.html`
- `game.js`
- `style.css`
- `render.yaml`
- GitHub

A chave deve ficar em `OPENAI_API_KEY` no ambiente do servidor.

## Rodar localmente

```bash
npm install
```

Crie `.env` a partir de `.env.example`, coloque a chave e execute:

```bash
npm start
```

Abra:

```text
http://localhost:3000
```

## Observação importante sobre persistência

A versão atual salva a partida no `localStorage` do navegador. Isso funciona para jogar no mesmo navegador/dispositivo, mas não é uma conta online.

Para uma versão multiplayer/persistente, o próximo passo é adicionar banco de dados e autenticação, salvando personagem, mundo, NPCs e histórico no servidor.

## Fluxo

Navegador
→ `/api/turn`
→ backend
→ modelo de IA
→ JSON estruturado
→ aplicação das consequências
→ nova cena
→ navegador

A chave permanece no servidor.
