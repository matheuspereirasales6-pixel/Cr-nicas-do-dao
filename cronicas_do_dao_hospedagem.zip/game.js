(() => {
"use strict";

/*
  CRÔNICAS DO DAO — cliente
  O navegador NÃO recebe a chave da API.
  Ele chama POST /api/turn no backend.
*/

const R={
  pick:a=>a[Math.floor(Math.random()*a.length)],
  int:(a,b)=>Math.floor(Math.random()*(b-a+1))+a,
  clamp:(n,a,b)=>Math.max(a,Math.min(b,n))
};

const REALMS=[
  {name:"Mortal",need:0},{name:"Refinamento Corporal",need:40},
  {name:"Refinamento de Qi",need:120},{name:"Fundação Espiritual",need:260},
  {name:"Núcleo Dourado",need:520},{name:"Alma Nascente",need:1000},
  {name:"Transformação Divina",need:1800},{name:"Reino da Formação",need:3000},
  {name:"Reino do Dao",need:5000}
];

const DATA={
 first:["Wei","Lin","Shen","Qin","Luo","Bai","Han","Ye","Su","Jiang","Mu","Feng","Tang","Zhao","Gu","Xue","Ren","Mo"],
 last:["Chen","Yun","Kai","Rui","Tao","Ming","Lan","Jin","Xu","Hao","Feng","Qing","Long","Shan"],
 regions:["Império de Tianyuan","Continente de Yun","Vale das Cem Montanhas","Mar Interior","Terras do Norte","Província de Qing","Fronteira do Crepúsculo","Domínio das Nove Montanhas"],
 races:["Humano","Humano de sangue espiritual","Espírito","Bestial","Demônio antigo","Descendente celestial"],
 bloods:["Comum","Sangue espiritual","Linhagem do Trovão","Linhagem Lunar","Linhagem de uma besta ancestral","Linhagem Celestial adormecida","Origem desconhecida"],
 talents:["Raiz espiritual de Fogo","Raiz espiritual de Água","Raiz espiritual de Madeira","Raiz espiritual de Metal","Raiz espiritual de Terra","Raiz dos Cinco Elementos","Afinidade com espada","Compreensão extraordinária","Corpo excepcional","Alma sensível","Talento aparentemente comum"],
 families:["Casa Chen","Clã Yun","Família Luo","Clã da Garça Azul","Casa da Montanha Branca","Família sem nome","Clã do Rio Frio","Casa do Vale Vermelho"],
 locations:["Vila do Rio Nebuloso","Cidade da Lua Branca","Mercado dos Cultivadores","Floresta do Véu Verde","Montanha do Sino Partido","Cidade das Cem Forjas","Porto do Mar Interior"]
};

function freshState(){
 const name=R.pick(DATA.first)+" "+R.pick(DATA.last());
 return {
  name,race:R.pick(DATA.races),blood:R.pick(DATA.bloods),talent:R.pick(DATA.talents),
  region:R.pick(DATA.regions),family:R.pick(DATA.families),location:R.pick(DATA.locations),
  father:R.pick(["Chen Rui","Luo Han","Shen Tao","Wei Ming","Qin Long"]),
  mother:R.pick(["Yun Mei","Bai Lan","Su Qing","Lin Yue","Jiang Xue"]),
  sibling:R.pick([null,null,null,R.pick(DATA.first)+" "+R.pick(DATA.last())]),
  sect:null,age:0,year:1,month:1,day:1,chapter:1,
  chapterTitle:"O primeiro sopro",realm:0,cultivation:0,
  body:R.int(5,15),qi:R.int(1,8),soul:R.int(4,12),
  comprehension:R.int(5,15),will:R.int(5,15),luck:R.int(1,12),
  reputation:0,spiritStones:0,inventory:[],discoveries:[],
  relations:{},flags:{},completed:[],journal:[],turn:0,
  storyHistory:[],lastAction:""
 };
}

let state=freshState();
let currentChoices=[];
let currentTab="journal";
let busy=false;

const $=id=>document.getElementById(id);
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function toast(t){const e=$("toast");e.textContent=t;e.classList.add("show");setTimeout(()=>e.classList.remove("show"),2200)}
function addLog(t){state.journal.unshift({year:state.year,age:state.age,text:t});state.journal=state.journal.slice(0,150)}
function setStory(text){$("story").innerHTML=String(text||"").split(/\n+/).filter(Boolean).map(p=>`<p>${esc(p)}</p>`).join("")}
function system(t){$("story").innerHTML+=`<p class="system">${esc(t)}</p>`}

function render(){
 $("charName").textContent=state.name;
 $("charOrigin").textContent=`${state.race} • ${state.blood}`;
 $("avatar").textContent=state.name?.charAt(0)||"?";
 $("ageText").textContent=`${state.age} ${state.age===1?"ano":"anos"}`;
 $("dateText").textContent=`Ano ${state.year} • Mês ${state.month}`;
 $("bodyStat").textContent=state.body;$("qiStat").textContent=state.qi;
 $("soulStat").textContent=state.soul;$("compStat").textContent=state.comprehension;
 $("willStat").textContent=state.will;$("luckStat").textContent=state.luck;
 $("repStat").textContent=state.reputation;$("stoneStat").textContent=state.spiritStones;
 $("realmText").textContent=REALMS[state.realm]?.name||"Desconhecido";
 const next=REALMS[state.realm+1],prev=REALMS[state.realm]?.need||0;
 const pct=next?Math.max(0,Math.min(100,((state.cultivation-prev)/(next.need-prev))*100)):100;
 $("cultivationBar").style.width=pct+"%";
 $("cultivationText").textContent=next?`${state.cultivation} / ${next.need} para ${next.name}`:"Além do limite atual";
 $("raceText").textContent=state.race;$("bloodText").textContent=state.blood;
 $("talentText").textContent=state.talent;$("familyText").textContent=state.family;
 $("regionText").textContent=state.region;$("locationText").textContent=state.location;
 $("chapterType").textContent=`CAPÍTULO ${state.chapter}`;
 $("chapterTitle").textContent=state.chapterTitle;
 renderRelations();renderChoices();renderTab(currentTab);
}

function renderRelations(){
 const box=$("relations");box.innerHTML="";
 Object.entries(state.relations||{}).forEach(([n,v])=>{
  const d=document.createElement("div");d.className="relation";
  d.innerHTML=`<span>${esc(n)}</span><span>${esc(v)}</span>`;box.appendChild(d);
 });
}
function renderChoices(){
 const box=$("choices");box.innerHTML="";
 currentChoices.forEach((c,i)=>{
  const b=document.createElement("button");b.className="choice";
  b.innerHTML=`<span class="num">${i+1}</span><span><span class="choice-title">${esc(c.label)}</span><small>${esc(c.hint||"")}</small></span>`;
  b.onclick=()=>play(c.label);
  box.appendChild(b);
 });
}
function renderTab(tab){
 currentTab=tab;document.querySelectorAll(".tab").forEach(b=>b.classList.toggle("active",b.dataset.tab===tab));
 const c=$("tabContent");
 if(tab==="journal")c.innerHTML=(state.journal||[]).map(x=>`<div class="log-entry"><time>A${x.year}</time>${esc(x.text)}</div>`).join("")||"Nenhum acontecimento.";
 if(tab==="inventory")c.innerHTML=(state.inventory||[]).map(x=>`<span class="item">${esc(x)}</span>`).join("")||"Inventário vazio.";
 if(tab==="discoveries")c.innerHTML=(state.discoveries||[]).map(x=>`<div class="log-entry">◆ ${esc(x)}</div>`).join("")||"Nenhuma descoberta.";
 if(tab==="world")c.innerHTML=`<div class="log-entry"><b>Local:</b> ${esc(state.location)}</div>
 <div class="log-entry"><b>Região:</b> ${esc(state.region)}</div>
 <div class="log-entry"><b>Seita:</b> ${esc(state.sect||"Nenhuma")}</div>
 <div class="log-entry"><b>Eventos registrados:</b> ${(state.completed||[]).length}</div>
 <div class="log-entry"><b>Turnos:</b> ${state.turn}</div>`;
}
document.querySelectorAll(".tab").forEach(b=>b.onclick=()=>renderTab(b.dataset.tab));

function localSave(){localStorage.setItem("cronicas_do_dao_ai",JSON.stringify(state))}
function localLoad(){
 try{const x=localStorage.getItem("cronicas_do_dao_ai");return x?JSON.parse(x):null}catch{return null}
}

async function apiTurn(action){
 if(busy)return;
 busy=true;
 $("actBtn").disabled=true;
 $("actBtn").textContent="Narrando...";
 try{
  const res=await fetch("/api/turn",{
   method:"POST",headers:{"Content-Type":"application/json"},
   body:JSON.stringify({state,action})
  });
  const data=await res.json();
  if(!res.ok)throw new Error(data.error||"Erro no servidor");
  state=data.state;
  currentChoices=data.choices||[];
  setStory(data.story);
  system(`Ano ${state.year}, ${state.age} anos — ${data.scene_type||"acontecimento"}.`);
  addLog(data.log||"A história avançou.");
  state.storyHistory=(state.storyHistory||[]).concat([{
   action,story:data.story,year:state.year,age:state.age
  }]).slice(-30);
  localSave();render();
 }catch(err){
  toast(err.message);
  console.error(err);
 }finally{
  busy=false;$("actBtn").disabled=false;$("actBtn").textContent="Agir";
 }
}
function play(action){apiTurn(action)}
$("actBtn").onclick=()=>{const v=$("actionInput").value.trim();if(v){$("actionInput").value="";play(v)}};
$("actionInput").addEventListener("keydown",e=>{
 if(e.key==="Enter"&&(e.ctrlKey||e.metaKey)){e.preventDefault();$("actBtn").click()}
});

$("saveBtn").onclick=()=>{localSave();toast("Partida salva no navegador.")};
$("loadBtn").onclick=()=>{const s=localLoad();if(!s){toast("Nenhuma partida local.");return}state=s;currentChoices=[];render();toast("Partida carregada.")};
$("newGameBtn").onclick=()=>{if(confirm("Começar uma nova vida?")){state=freshState();currentChoices=[];localSave();render();play("Nasci e observo o mundo ao meu redor.")}};

async function boot(){
 const saved=localLoad();if(saved)state=saved;
 render();
 if(!saved)await play("Nasci. Quero que minha vida comece agora, com um mundo que exista independentemente das minhas escolhas.");
}
boot();
})();